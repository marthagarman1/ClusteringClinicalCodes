﻿DELETE FROM [aspnet-ClinicalCodeClusteringWebApp-A345E173-EF1B-4546-9C65-95A9181858FC].dbo.Claims

DELETE FROM [aspnet-ClinicalCodeClusteringWebApp-A345E173-EF1B-4546-9C65-95A9181858FC].dbo.CPT_Cats

